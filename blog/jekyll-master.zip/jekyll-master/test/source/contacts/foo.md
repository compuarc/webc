---
title: Contact Information
---

## {{ page.title }}

In case of emergency, contact Mr. John Doe, 1234, Foo Road, Foo.
