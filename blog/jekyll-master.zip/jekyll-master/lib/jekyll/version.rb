# frozen_string_literal: true

module Jekyll
  VERSION = "4.3.3"
end
